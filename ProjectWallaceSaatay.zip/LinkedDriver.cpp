#include "linkedlist.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>
#include <unistd.h>
#include <thread>
#include <cstdlib>
using namespace std;

int main(int argc, char *argv[])
{
    if(argc!=2) // if the correct amount of command line arguments returns error message
    {
        cout << "Invalid number of arg provided" << endl;
    }
    const int size = 40000; // size of the testData array
    int testData[size];
    float insertion[400];
    float searched[400]; 

    ifstream file(argv[1]); // sets the second argument to the filename
    string line = " "; // line is empty
    //string temp[1];
    int num;
    int index;
    int search_index = 100;

        int i=0;
        while(getline(file,line,',')) // treats the file as one line separated by a comma
        {
            
           // string word;
            //istringstream ss(line);
            num = stoi(line); // converts all the strings of the file to integers
            testData[i] = num; // fills the testData array with integers
           i++; // increments i for new line

        }
        for(int i=0; i < size; ++i)
        {
           cout << testData[i] << endl;
        }
       

        Linked ll;

        using namespace chrono; // time tag
        chrono::duration<double>execTime; // execution time is a double value
        chrono::high_resolution_clock::time_point start, end; // creates a clock with a start and an end
        Node * head = NULL; // sets the linked list to empty
        cout << "Linked List Insertion Time" << endl;
        for(int j=0; j < 400; j++) // iterating over insertion
        {

           // high_resolution_clock::time_point start, end;
            start = high_resolution_clock::now(); // starts the clock
            for(int i = 100*j; i < 100*j+100; ++i) // allows the increment of data 0-99, 100-199....
            {
                ll.insert(testData[i]);
            }
            //this_thread::sleep_for(seconds(2));
            end = high_resolution_clock::now();
            execTime = duration_cast<microseconds>(end-start); // outputs time in microseconds

            insertion[i] = execTime.count() / 100;
            // cout << insertion[i] << endl;
        }
      
            for(int i=0; i < 400; ++i) // loops 400 times for the total number of searches
            {
                start = high_resolution_clock::now(); //starts the clock

                    for(int j=0; j<=100; j++)
                    {
                        index = (rand() % search_index); // generates a random index within the bounds
                        ll.search(testData[index]);
                    }
                    search_index += 100; // increments the search index by 100 for the random index generator
                    end = high_resolution_clock::now();
                    execTime = duration_cast<microseconds>(end-start);
                    searched[i] = execTime.count() / 100; // wanna see total of a trial
                    cout <<  searched[i] << endl;
            }

        
    ofstream myFile("LLinsert.csv"); // writes to a file
    for(int i=0; i < 400.0; ++i) // loops through while less than the size of search and insertion
    {
        myFile << i << ", " << searched[i] << endl;
    }

/*
Linked LL;
Node * head = NULL;
LL.insert(2);
cout << "hello" << endl;
LL.prettyPrint();
*/

      

 
}